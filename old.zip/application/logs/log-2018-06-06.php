<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-06 17:02:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/jenner/public_html/msw-dev-leave-sites/application/controllers/Welcome.php 189
ERROR - 2018-06-06 05:11:00 --> 404 Page Not Found: Assets/js
ERROR - 2018-06-06 05:11:00 --> 404 Page Not Found: Assets/css
ERROR - 2018-06-06 17:14:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/jenner/public_html/msw-dev-leave-sites/application/controllers/Welcome.php 189
ERROR - 2018-06-06 17:14:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/jenner/public_html/msw-dev-leave-sites/application/controllers/Welcome.php 189
ERROR - 2018-06-06 17:25:37 --> Severity: Warning --> Invalid argument supplied for foreach() /home/jenner/public_html/msw-dev-leave-sites/application/controllers/Welcome.php 189
ERROR - 2018-06-06 17:25:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/jenner/public_html/msw-dev-leave-sites/application/controllers/Welcome.php 189
ERROR - 2018-06-06 17:32:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/jenner/public_html/msw-dev-leave-sites/application/controllers/Welcome.php 189
ERROR - 2018-06-06 17:37:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/jenner/public_html/msw-dev-leave-sites/application/controllers/Welcome.php 189
ERROR - 2018-06-06 21:28:42 --> 404 Page Not Found: Assets/css
ERROR - 2018-06-06 21:28:42 --> 404 Page Not Found: Assets/js
ERROR - 2018-06-06 21:30:51 --> 404 Page Not Found: Assets/js
ERROR - 2018-06-06 21:30:52 --> 404 Page Not Found: Assets/css
