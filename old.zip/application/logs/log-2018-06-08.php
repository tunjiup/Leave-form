<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-08 12:06:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/jenner/public_html/msw-dev-leave-sites/application/controllers/Welcome.php 189
