<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-07 09:13:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/jenner/public_html/msw-dev-leave-sites/application/controllers/Welcome.php 189
ERROR - 2018-06-07 09:16:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/jenner/public_html/msw-dev-leave-sites/application/controllers/Welcome.php 189
ERROR - 2018-06-07 09:18:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/jenner/public_html/msw-dev-leave-sites/application/controllers/Welcome.php 189
ERROR - 2018-06-07 09:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/jenner/public_html/msw-dev-leave-sites/application/controllers/Welcome.php 189
ERROR - 2018-06-07 09:18:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/jenner/public_html/msw-dev-leave-sites/application/controllers/Welcome.php 189
ERROR - 2018-06-07 09:19:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/jenner/public_html/msw-dev-leave-sites/application/controllers/Welcome.php 189
ERROR - 2018-06-07 09:21:22 --> Severity: Warning --> Invalid argument supplied for foreach() /home/jenner/public_html/msw-dev-leave-sites/application/controllers/Welcome.php 189
ERROR - 2018-06-07 09:30:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/jenner/public_html/msw-dev-leave-sites/application/controllers/Welcome.php 189
ERROR - 2018-06-07 09:34:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/jenner/public_html/msw-dev-leave-sites/application/controllers/Welcome.php 189
ERROR - 2018-06-07 09:39:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/jenner/public_html/msw-dev-leave-sites/application/controllers/Welcome.php 189
ERROR - 2018-06-07 09:44:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/jenner/public_html/msw-dev-leave-sites/application/controllers/Welcome.php 189
ERROR - 2018-06-07 00:52:55 --> 404 Page Not Found: Assets/css
ERROR - 2018-06-07 15:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/jenner/public_html/msw-dev-leave-sites/application/controllers/Welcome.php 189
