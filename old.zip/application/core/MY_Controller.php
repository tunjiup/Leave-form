<?php

class MY_Controller extends CI_Controller {
	
	private $_validate_fields = FALSE;
	private $_ci = null;

	function __construct() {
		parent::__construct();
		date_default_timezone_set('Asia/Manila');
		$this->load->helper('string');
		$this->_ci =& get_instance();
		$this->load->helper('cs_password');
		$this->load->config('validations');
		$this->load->helper('cs_dropdown');
		$this->emailSetting();
		$this->_ci =& get_instance();
		$this->_ci->load->model('M_leave','leave');
	}

	public function getHolidays() {
		$hapi = new Version1('bc4cb088-50df-45c0-9cd8-e540f5cee2f8');
		$year = date('Y');
		$month = date('m');
		$parameters = array(
			'country' => 'PH',
			'year'    => $year,
			'month'    => $month,
		);

		$response = $hapi->holidays($parameters);

		return $response;
	}

	public function displayHoliday() {
		$year = date('Y');
		$month = date('m');
    	$url = "https://holidayapi.com/v1/holidays?key=bc4cb088-50df-45c0-9cd8-e540f5cee2f8&country=PH&year=".$year."&month=".$month."";
    	$curl = curl_init();
    	curl_setopt($curl, CURLOPT_URL, $url);
    	curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    	curl_setopt($curl, CURLOPT_TIMEOUT, 10);
    	$res = curl_exec($curl);
	    curl_close($curl);
	    $holiday = json_decode($res, true);
	    return $holiday;
    }

	/**
     * Tell the controller to load the form validation library and set delimiter.
     * @param array $rules
     */
	public function require_validation($rules = null) {

		$this->form_validation->set_error_delimiters('<p class="text-danger">', '</p>');

		if(is_array($rules)) {
			$this->form_validation->set_rules($rules);
		}

		$this->_validate_fields = TRUE;
	}

	/**
	* Generate Activation code
	* @return String
	*/
	public function genCode($int) {

		$code = random_string('alnum', $int);

		return $code;
	}

	/**
	* Email Template Leave
	*/
	public function resetEmailTemplate($res,$reset){
		$sitename = strtolower($_SERVER['SERVER_NAME']);
		$from_email = 'no-reply@'.$sitename;

			
		$message = '<b>Hi '.$res['username'].'!</b><br /><br />

					To change yourpassword please click the link below <br />
					<br /> <a href="'.base_url('verify/').$reset.'" style="width: 100px; padding: 5px 10px; font-size: 12px; line-height: 1.5; border-radius: 3px; background-color: #337ab7; border: 1px solid #2e6da4; text-align: center; color: #fff; text-decoration: none; ">Verify Account</a><br />
					<br /> or Copy this link and paste to browser '.base_url('verify/').$reset;

		$this->email->from($from_email,'Password Reset'); 
		$this->email->to($res['email']);
		$this->email->subject('Password Reset'); 
		$this->email->message($message);
	}

	public function sentManager($res,$data,$token){

		$manager = $res['manager'];
		$recipient = $this->leave->getManagerEmail($manager);
		$sitename = strtolower($_SERVER['SERVER_NAME']);
		$from_email = 'leave-form@'.$sitename;

		if($data['days'] == 1) {
			$message = '<b>Hi '.$manager.'!</b><br /><br />

					I would like to file a '.$data['title'].' for '.$data['days'].' day, '.date('M d, Y',strtotime($data['start'])).'. Grateful if you can approve my request.<br /><br />

					<a href="'.base_url('approved/').$token.'" style="width: 100px; padding: 5px 10px; font-size: 12px; line-height: 1.5; border-radius: 3px; background-color: #337ab7; border: 1px solid #2e6da4; text-align: center; color: #fff; text-decoration: none; ">Approved</a><br /><br />

					Regards,<br />
					'.$res['fullname'];
		} else {
			$message = '<b>Hi '.$manager.'!</b><br /><br />

					I would like to file a '.$data['title'].' for '.$data['days'].' day/s, from '.date('M d, Y',strtotime($data['start'])).' to '.date('M d, Y',strtotime($data['end'])).'. Grateful if you can approve my request.<br /><br />

					<a href="'.base_url('approved/').$token.'" style="width: 100px; padding: 5px 10px; font-size: 12px; line-height: 1.5; border-radius: 3px; background-color: #337ab7; border: 1px solid #2e6da4; text-align: center; color: #fff; text-decoration: none; ">Approved</a><br /><br />

					Regards,<br />
					'.$res['fullname'];
		}

		$this->email->from($from_email,'Leave Form'); 
		$this->email->to($recipient['email']);
		$this->email->subject('For approval '.$data['title']);
		$this->email->message($message);
		$this->email->reply_to($res['email']);
	}

	public function approvedMail($data,$verify) {
		$manager = $res['manager'];
		$sitename = strtolower($_SERVER['SERVER_NAME']);
		$from_email = 'leave-approved@'.$sitename;

		if($verify['days'] == 1) {
			$message = '<b>Hi '.$data['fullname'].'!</b><br /><br />

					Your '.$verify['title'].' for '.$verify['days'].' day, '.date('M d, Y',strtotime($verify['start'])).'. has been approved.<br /><br />

					Regards<br />';
		} else {
			$message = '<b>Hi '.$data['fullname'].'!</b><br /><br />

					Your '.$verify['title'].' for '.$verify['days'].' day/s, from '.date('M d, Y',strtotime($verify['start'])).' to '.date('M d, Y',strtotime($verify['end'])).'. has been approved.<br /><br />

					Regards<br />';
		}

		$this->email->from($from_email,'Leave Approved'); 
		$this->email->to($data['email']);
		$this->email->subject($verify['title'].' Approved');
		$this->email->message($message);

		if($this->email->send()) {

			$this->session->set_flashdata('approved','Yess');
			redirect(base_url());

		} else {
			$this->session->set_flashdata('notsent','<div class="alert alert-danger">Oops, Email not sent</div>');
		}
	}

	public function trigerSend() {

		if($this->email->send()) {

			$this->session->set_flashdata('sent',"<div class='alert alert-success'>We sent you an email with password reset instructions.</div>");
			redirect('login');

		} else {
			$this->session->set_flashdata('notsent','<div class="alert alert-danger">Oops, Email not sent</div>');
		}
	}

	public function emailSetting() {
		$config = Array(
			'protocol' => 'smtp',
			'smtp_host' => 'ssl://smtp.googlemail.com',
			'smtp_port' => 465,
			'smtp_user' => 'mswdummy2017@gmail.com',
			'smtp_pass' => 'mwsdummy2017',
			'charset'   => 'iso-8859-1'
		);
		$this->load->library('email', $config);
		$this->email->set_mailtype("html");
	}
}

?>