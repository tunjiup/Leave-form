$(document).ready(function(){
    $('#modalChangePass').click(function(){
        $('#changePass').modal('show');
        $('#editProfile').modal('hide');
    });
});